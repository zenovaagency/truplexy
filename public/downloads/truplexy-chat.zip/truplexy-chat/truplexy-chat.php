<?php
/**
 * Plugin Name:       Truplexy Chat
 * Plugin URI:        https://truplexy.com/docs/web-sdk
 * Description:       Adds the Truplexy AI support chat to your site. Your chat key stays on the server.
 * Author:            Truplexy
 * Author URI:        https://truplexy.com
 * Version:           1.0.6
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * License:           MIT
 * License URI:       https://opensource.org/licenses/MIT
 * Text Domain:       truplexy-chat
 *
 * Put your chat key in wp-config.php:  define('TRUPLEXY_CHAT_KEY', 'tpx_...');
 * How the chat looks is set in the Truplexy dashboard (Integrations → Chat widget), once for every place it is shown.
 */

if (!defined('ABSPATH')) {
    exit;
}

const TRUPLEXY_CHAT_VERSION = '1.0.6';

function truplexy_chat_settings(): array {
    return wp_parse_args(get_option('truplexy_chat', []), [
        'enabled'           => '1',
        'chat_key'          => '',
        'keep_tickets_open' => '',
    ]);
}

/** The chat key: wp-config.php first, then the settings page. */
function truplexy_chat_key(): string {
    return defined('TRUPLEXY_CHAT_KEY') ? (string) TRUPLEXY_CHAT_KEY : (string) truplexy_chat_settings()['chat_key'];
}

function truplexy_chat_api_base(): string {
    return rtrim(defined('TRUPLEXY_API_BASE') ? TRUPLEXY_API_BASE : 'https://api.truplexy.com/v3', '/');
}

/* -------------------------------------------------------------------------
 * Sessions: a signed conversation ID the visitor's browser keeps (see PROTOCOL.md).
 * ---------------------------------------------------------------------- */

function truplexy_chat_secret(): string {
    return defined('TRUPLEXY_SESSION_SECRET') ? (string) TRUPLEXY_SESSION_SECRET : truplexy_chat_key();
}

function truplexy_chat_b64(string $bytes): string {
    return rtrim(strtr(base64_encode($bytes), '+/', '-_'), '=');
}

function truplexy_chat_unb64(string $text) {
    if (!preg_match('/^[A-Za-z0-9_-]*$/', $text)) {
        return false;
    }
    return base64_decode(strtr($text, '-_', '+/') . str_repeat('=', (4 - strlen($text) % 4) % 4), true);
}

function truplexy_chat_sign(string $conversation): string {
    $payload = $conversation . '.' . time();
    return truplexy_chat_b64($payload) . '.' . truplexy_chat_b64(hash_hmac('sha256', $payload, truplexy_chat_secret(), true));
}

/** The conversation ID of a valid, unexpired session, or null. */
function truplexy_chat_verify($token): ?string {
    if (!is_string($token) || strlen($token) > 512 || substr_count($token, '.') !== 1) {
        return null;
    }
    list($p, $s) = explode('.', $token);
    $payload = truplexy_chat_unb64($p);
    $signature = truplexy_chat_unb64($s);
    if ($payload === false || $signature === false) {
        return null;
    }
    if (!hash_equals(hash_hmac('sha256', $payload, truplexy_chat_secret(), true), $signature)) {
        return null;
    }
    if (!preg_match('/^(conv_[0-9a-f]{32})\.(\d{1,12})$/', $payload, $m)) {
        return null;
    }
    $age = time() - (int) $m[2];
    return ($age >= -300 && $age <= 30 * DAY_IN_SECONDS) ? $m[1] : null;
}

/* -------------------------------------------------------------------------
 * The chat API.
 * ---------------------------------------------------------------------- */

/** Notes a failed Truplexy call in the PHP error log, only when the site logs for debugging (WP_DEBUG_LOG). */
function truplexy_chat_log(string $message): void {
    if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
        error_log('[truplexy-chat] ' . $message); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- opt-in through WP_DEBUG_LOG.
    }
}

class Truplexy_Chat_Error extends Exception {
    public $api_code;
    public $request_id;
    public $status;

    public function __construct(string $api_code, string $request_id = '', int $status = 502) {
        parent::__construct($api_code);
        $this->api_code = $api_code;
        $this->request_id = $request_id;
        $this->status = $status;
    }
}

function truplexy_chat_api(string $method, string $path, ?array $body = null, bool $retry = true, int $timeout = 55): array {
    $res = wp_remote_request(truplexy_chat_api_base() . $path, [
        'method'  => $method,
        'timeout' => $timeout,
        'headers' => ['Authorization' => 'Bearer ' . truplexy_chat_key(), 'Content-Type' => 'application/json'],
        'body'    => $body === null ? null : wp_json_encode($body),
    ]);
    if (is_wp_error($res)) {
        throw new Truplexy_Chat_Error('UPSTREAM_ERROR');
    }
    $status = (int) wp_remote_retrieve_response_code($res);
    $data = json_decode(wp_remote_retrieve_body($res), true);
    if ($retry && $method === 'PUT' && $path === '/customer' && $status === 409 && ($data['error']['code'] ?? '') === 'CUSTOMER_EXISTS') {
        return truplexy_chat_api($method, $path, $body, false, $timeout);
    }
    if ($status >= 300) {
        $code = $status === 401 ? 'NOT_CONFIGURED' : ($data['error']['code'] ?? 'UPSTREAM_ERROR');
        throw new Truplexy_Chat_Error(esc_html($code), esc_html((string) ($data['error']['request_id'] ?? wp_remote_retrieve_header($res, 'x-request-id'))), absint($status));
    }
    return is_array($data) ? $data : [];
}

/** What the visitor may see: no background context, only the public fields. */
function truplexy_chat_public(array $conversation): array {
    $messages = [];
    foreach ($conversation['messages'] ?? [] as $m) {
        if ($m['role'] === 'user' && strpos($m['content'], '[Context only') === 0) {
            continue;
        }
        $messages[] = array_intersect_key($m, array_flip(['id', 'role', 'content', 'author', 'agent', 'created_at']));
    }
    $public = ['status' => $conversation['status'] ?? 'open', 'escalated' => !empty($conversation['escalated']), 'messages' => $messages];
    if (is_array($conversation['ticket'] ?? null)) {
        // Only the id, whether it is closed and when: a closed chat is shown read-only.
        $public['ticket'] = array_intersect_key($conversation['ticket'], array_flip(['id', 'status', 'closed_at']));
    }
    return $public;
}

/** An error the widget can show. Never passes on the API's own message. */
function truplexy_chat_error(string $code, string $request_id = ''): WP_REST_Response {
    $known = [
        'CUSTOMER_CONFLICT'  => [409, 'Your contact details could not be linked. Please contact support.'],
        'CUSTOMER_EXISTS'    => [409, 'Your contact details could not be saved. Please try again.'],
        'INVALID_REQUEST'    => [400, 'Check your message and customer details.'],
        'TICKET_CLOSED'      => [409, 'This conversation is closed. Start a new one.'],
        'RATE_LIMITED'       => [429, 'You are sending messages too quickly. Please wait a moment.'],
        'CHANNEL_DISABLED'   => [503, 'Chat is turned off right now.'],
        'TENANT_SUSPENDED'   => [503, 'Chat is turned off right now.'],
        'PLAN_LIMIT_REACHED' => [503, "The assistant can't reply right now. Please try again later."],
        'LLM_RATE_LIMITED'   => [429, 'The assistant is busy. Please try again in a moment.'],
        'LLM_TIMEOUT'        => [504, 'The reply took too long. Please try again.'],
        'TIMEOUT'            => [504, 'The reply took too long. Please try again.'],
        'NOT_CONFIGURED'     => [500, 'Chat is not set up yet.'],
    ];
    if (!isset($known[$code])) {
        $code = 'UPSTREAM_ERROR';
    }
    list($status, $message) = $known[$code] ?? [502, 'Chat is unavailable right now.'];
    $error = ['code' => $code, 'message' => $message];
    if ($request_id !== '') {
        $error['request_id'] = $request_id;
    }
    return new WP_REST_Response(['error' => $error], $status);
}

/** A simple per-visitor limit on messages; change it with the truplexy_chat_rate_limit filter. */
function truplexy_chat_allow(): bool {
    $limit = (int) apply_filters('truplexy_chat_rate_limit', 20);
    $key = 'truplexy_rl_' . md5(sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'] ?? '')));
    $count = (int) get_transient($key);
    if ($limit > 0 && $count >= $limit) {
        return false;
    }
    set_transient($key, $count + 1, MINUTE_IN_SECONDS);
    return true;
}

/* -------------------------------------------------------------------------
 * The route the widget talks to: POST /wp-json/truplexy/v1/chat
 * ---------------------------------------------------------------------- */

add_action('rest_api_init', function () {
    register_rest_route('truplexy/v1', '/chat', [
        'methods'             => 'POST',
        'permission_callback' => '__return_true',
        'callback'            => 'truplexy_chat_route',
    ]);
});

/** Starts a new conversation; customer linking is required, context and tickets are best effort. */
function truplexy_chat_start(WP_REST_Request $request, $raw): array {
    $user_id = (int) wp_validate_auth_cookie('', 'logged_in');
    $customer = apply_filters('truplexy_chat_customer', null, $request, $user_id);
    if ($customer === null && $raw !== null) {
        $name = is_array($raw) ? trim((string) ($raw['name'] ?? '')) : '';
        $email = is_array($raw) ? trim((string) ($raw['email'] ?? '')) : '';
        if ($name === '' || mb_strlen($name) > 120 || strlen($email) > 254 || !is_email($email)) throw new Truplexy_Chat_Error('INVALID_REQUEST');
        $customer = ['name' => $name, 'contacts' => [['type' => 'email', 'value' => $email]]];
    }
    $opening = defined('TRUPLEXY_CHANNEL_ID') ? ['channel_id' => TRUPLEXY_CHANNEL_ID] : [];
    if ($customer !== null) {
        $known = truplexy_chat_api('PUT', '/customer', $customer);
        if (empty($known['id'])) throw new Truplexy_Chat_Error('UPSTREAM_ERROR');
        $opening['customer_id'] = $known['id'];
    }
    $name = $customer['name'] ?? '';
    $background = '';
    try {
        $context = (string) apply_filters('truplexy_chat_context', '', $request, $user_id);
        $background = mb_substr(trim(($name ? 'Customer: ' . $name . '. ' : '') . $context), 0, 4000);
    } catch (Throwable $e) { truplexy_chat_log('Background context unavailable'); }
    $opening_ticket = ['subject' => mb_substr($name ? 'Chat with ' . $name : 'Website chat', 0, 200)];
    // Without keep_open, the ticket closes on its own after the business's auto-close time.
    if (truplexy_chat_settings()['keep_tickets_open']) $opening_ticket['keep_open'] = true;
    // One call starts the conversation, passes the background and opens the ticket (both best effort).
    // An API from before they could be sent together refuses the fields: then each is its own call.
    try {
        $created = truplexy_chat_api('POST', '/conversations', $opening + ($background !== '' ? ['context' => $background] : []) + ['ticket' => $opening_ticket]);
    } catch (Truplexy_Chat_Error $e) {
        if ($e->api_code !== 'INVALID_REQUEST') throw $e;
        $created = truplexy_chat_api('POST', '/conversations', $opening ?: null);
        try {
            if ($background !== '') truplexy_chat_api('POST', "/conversations/{$created['id']}/messages", ['message' => mb_substr('[Context only] ' . $background, 0, 4000)]);
        } catch (Throwable $e) { truplexy_chat_log('Background context unavailable'); }
    }
    $conv = $created['id'];
    $t = $created['ticket'] ?? null;
    if (!is_array($t)) {
        try {
            $t = truplexy_chat_api('POST', "/conversations/$conv/ticket", $opening_ticket);
        } catch (Truplexy_Chat_Error $e) { truplexy_chat_log($e->api_code); }
    }
    $ticket = is_array($t) ? array_intersect_key($t, array_flip(['id', 'subject', 'status'])) : null;
    return [$conv, $ticket];
}

function truplexy_chat_route(WP_REST_Request $request) {
    $in = $request->get_json_params();
    if (!is_array($in)) {
        return truplexy_chat_error('INVALID_REQUEST');
    }
    if (truplexy_chat_key() === '') {
        return truplexy_chat_error('NOT_CONFIGURED');
    }
    $action = (string) ($in['action'] ?? '');
    $conv = truplexy_chat_verify($in['session'] ?? null);

    try {
        switch ($action) {
            case 'message':
                $text = trim((string) ($in['text'] ?? ''));
                if ($text === '' || mb_strlen($text) > 4000 || strpos($text, '[Context only') === 0) {
                    return truplexy_chat_error('INVALID_REQUEST');
                }
                if (!truplexy_chat_allow()) {
                    return truplexy_chat_error('RATE_LIMITED');
                }
                $ticket = null;
                $existing = (bool) $conv;
                if (!$conv) list($conv, $ticket) = truplexy_chat_start($request, $in['customer'] ?? null);
                try {
                    // A closed ticket ends the chat: the widget starts a new one, never this one again.
                    $r = truplexy_chat_api('POST', "/conversations/$conv/messages", ['message' => $text] + ($existing ? ['if_ticket_closed' => 'reject'] : []));
                } catch (Truplexy_Chat_Error $e) {
                    if ($e->api_code !== 'CONVERSATION_NOT_FOUND' || !truplexy_chat_verify($in['session'] ?? null)) throw $e;
                    list($conv, $ticket) = truplexy_chat_start($request, $in['customer'] ?? null);
                    $r = truplexy_chat_api('POST', "/conversations/$conv/messages", ['message' => $text]);
                }
                return [
                    'session' => truplexy_chat_sign($conv),
                    'message' => $r['message'] ?? null,
                    'reply'   => $r['reply'] ?? null,
                    'status'  => $r['status'] ?? 'answered',
                    'sources' => $r['sources'] ?? [],
                ] + ($ticket ? ['ticket' => $ticket] : []);

            case 'history':
                if (!$conv) {
                    return ['session' => null];
                }
                return ['session' => truplexy_chat_sign($conv), 'conversation' => truplexy_chat_public(truplexy_chat_api('GET', "/conversations/$conv"))];

            case 'handoff':
                if (!$conv) {
                    return truplexy_chat_error('INVALID_REQUEST');
                }
                return ['session' => truplexy_chat_sign($conv), 'conversation' => truplexy_chat_public(truplexy_chat_api('POST', "/conversations/$conv/handoff"))];

            case 'profile':
                // The business and bot name and picture, and how the business set the chat to look
                // (Truplexy dashboard: Integrations, Chat widget); the widget shows them.
                $p = truplexy_chat_api('GET', '/profile');
                $look = is_array($p['widget'] ?? null) ? array_intersect_key($p['widget'], array_flip(['heading', 'subtitle', 'greeting', 'placeholder', 'accent', 'theme', 'position', 'show_sources', 'details', 'suggestions', 'picture_url'])) : null;
                return [
                    'business' => ['name' => $p['business']['name'] ?? null, 'logo_url' => $p['business']['logo_url'] ?? null],
                    'bot'      => ['id' => $p['bot']['id'] ?? null, 'name' => $p['bot']['name'] ?? null, 'avatar_url' => $p['bot']['avatar_url'] ?? null],
                ] + ($look ? ['widget' => $look] : []);

            case 'live':
                if (!$conv) {
                    return new stdClass();
                }
                $live = truplexy_chat_api('POST', '/realtime/token', ['conversation_id' => $conv]);
                // Only the conversation's own topic: the bot topic carries every customer's messages.
                return (object) array_intersect_key($live, array_flip(['url', 'publishable_key', 'conversation_topic']));
        }
        return truplexy_chat_error('INVALID_REQUEST');
    } catch (Truplexy_Chat_Error $e) {
        if ($action === 'history' && $e->api_code === 'CONVERSATION_NOT_FOUND') {
            return ['session' => null];
        }
        if ($action === 'live' && $e->api_code === 'REALTIME_NOT_CONFIGURED') {
            return new stdClass();
        }
        truplexy_chat_log($e->api_code . ($e->request_id ? ' request_id=' . $e->request_id : ''));
        return truplexy_chat_error($e->api_code, $e->request_id);
    }
}

/* -------------------------------------------------------------------------
 * The widget on every page.
 * ---------------------------------------------------------------------- */

add_action('wp_enqueue_scripts', function () {
    $s = truplexy_chat_settings();
    if (!$s['enabled'] || truplexy_chat_key() === '') {
        return;
    }
    wp_enqueue_script('truplexy-chat', plugins_url('truplexy.min.js', __FILE__), [], TRUPLEXY_CHAT_VERSION, true);
});

add_filter('script_loader_tag', function ($tag, $handle) {
    if ($handle !== 'truplexy-chat') {
        return $tag;
    }
    // Only the route: the title, colours, side of the page and the rest come from the Truplexy
    // dashboard through the route's profile. An attribute set here would override them.
    $attrs = ['data-endpoint' => rest_url('truplexy/v1/chat')];
    if (apply_filters('truplexy_chat_details', 'ask') === 'off') {
        $attrs['data-details'] = 'off';
    }
    $storage_key = apply_filters('truplexy_chat_storage_key', '');
    if ($storage_key !== '') {
        $attrs['data-storage-key'] = $storage_key;
    }
    $html = '';
    foreach ($attrs as $name => $value) {
        $html .= ' ' . $name . '="' . esc_attr($value) . '"';
    }
    return str_replace(' src=', $html . ' defer src=', $tag);
}, 10, 2);

/* -------------------------------------------------------------------------
 * Settings → Truplexy Chat
 * ---------------------------------------------------------------------- */

add_action('admin_init', function () {
    register_setting('truplexy_chat', 'truplexy_chat', [
        'type'              => 'array',
        'sanitize_callback' => function ($in) {
            $in = is_array($in) ? $in : [];
            $old = truplexy_chat_settings();
            return [
                'enabled'           => empty($in['enabled']) ? '' : '1',
                // A blank key field keeps the saved key.
                'chat_key'          => !empty($in['chat_key']) ? sanitize_text_field($in['chat_key']) : $old['chat_key'],
                'keep_tickets_open' => empty($in['keep_tickets_open']) ? '' : '1',
            ];
        },
    ]);
});

register_activation_hook(__FILE__, function () {
    if (truplexy_chat_key() === '') {
        set_transient('truplexy_chat_welcome', '1', MINUTE_IN_SECONDS);
    }
});

add_action('admin_init', function () {
    if (!get_transient('truplexy_chat_welcome')) {
        return;
    }
    delete_transient('truplexy_chat_welcome');
    // Not for bulk activations, where several plugins are switched on at once.
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only asks whether WordPress is bulk-activating; nothing is read or saved.
    if (wp_doing_ajax() || isset($_GET['activate-multi']) || !current_user_can('manage_options')) {
        return;
    }
    wp_safe_redirect(admin_url('options-general.php?page=truplexy-chat'));
    exit;
});

add_action('admin_notices', function () {
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if (truplexy_chat_key() !== '' || !current_user_can('manage_options') || !$screen || !in_array($screen->id, ['plugins', 'dashboard'], true)) {
        return;
    }
    echo '<div class="notice notice-info"><p><strong>Truplexy Chat is almost ready.</strong> '
        . '<a href="' . esc_url(admin_url('options-general.php?page=truplexy-chat')) . '">Add your chat key</a> to show the chat on your site.</p></div>';
});

add_action('admin_menu', function () {
    add_options_page('Truplexy Chat', 'Truplexy Chat', 'manage_options', 'truplexy-chat', 'truplexy_chat_settings_page');
});

add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links) {
    array_unshift($links, '<a href="' . esc_url(admin_url('options-general.php?page=truplexy-chat')) . '">Settings</a>');
    return $links;
});

function truplexy_chat_settings_page() {
    $s = truplexy_chat_settings();
    $field = function ($key) {
        return 'truplexy_chat[' . $key . ']';
    };
    $status = null;
    if (truplexy_chat_key() !== '') {
        try {
            $profile = truplexy_chat_api('GET', '/profile', null, false, 8);
            $status = ['ok', 'Connected' . (!empty($profile['business']['name']) ? ' to ' . $profile['business']['name'] : '') . '.'];
        } catch (Truplexy_Chat_Error $e) {
            $status = ['error', $e->api_code === 'NOT_CONFIGURED' ? 'Truplexy did not accept this chat key. Check that you copied all of it.' : "Couldn't reach Truplexy (" . $e->api_code . '). The chat may not work until this is resolved.'];
        }
    }
    ?>
    <div class="wrap">
        <h1>Truplexy Chat</h1>
        <?php if ($status) : ?>
            <div class="notice notice-<?php echo $status[0] === 'ok' ? 'success' : 'error'; ?> inline"><p><?php echo esc_html($status[1]); ?></p></div>
        <?php endif; ?>
        <form method="post" action="options.php">
            <?php settings_fields('truplexy_chat'); ?>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row">Chat</th>
                    <td><label><input type="checkbox" name="<?php echo esc_attr($field('enabled')); ?>" value="1" <?php checked($s['enabled'], '1'); ?>> Show the chat on my site</label></td>
                </tr>
                <tr>
                    <th scope="row"><label for="truplexy-key">Chat key</label></th>
                    <td>
                        <?php if (defined('TRUPLEXY_CHAT_KEY')) : ?>
                            <p>Set in <code>wp-config.php</code>.</p>
                        <?php else : ?>
                            <input id="truplexy-key" type="password" class="regular-text" autocomplete="off" name="<?php echo esc_attr($field('chat_key')); ?>" placeholder="<?php echo esc_attr($s['chat_key'] ? 'Saved. Leave blank to keep it.' : 'tpx_...'); ?>">
                            <p class="description">Paste the chat key from the Truplexy dashboard (Integrations → WordPress), then save. Advanced: <code>define('TRUPLEXY_CHAT_KEY', 'tpx_...');</code> in <code>wp-config.php</code> keeps it out of the database.</p>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Appearance</th>
                    <td><p class="description">The title, greeting, colour, picture and position are set in the Truplexy dashboard under <strong>Integrations → Chat widget</strong>, once for every place the chat is shown.</p></td>
                </tr>
                <tr>
                    <th scope="row">Tickets</th>
                    <td><label><input type="checkbox" name="<?php echo esc_attr($field('keep_tickets_open')); ?>" value="1" <?php checked($s['keep_tickets_open'], '1'); ?>> Keep website chat tickets open until your team closes them</label></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}
