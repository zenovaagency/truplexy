=== Truplexy Chat ===
Contributors: tanvirhossen
Tags: chat, live chat, support, ai, chatbot
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.7
License: MIT

AI customer support that keeps one conversation going, with handoff to your team. Your chat key stays on your server.

== Description ==

Adds the Truplexy chat button to every page. Visitors get instant answers from your Truplexy knowledge base, can ask for a person, and see your team's replies right in the chat. It works on any WordPress site, including WooCommerce stores: the chat appears on shop, product, cart and checkout pages without a separate plugin.

The browser only talks to your own site (`/wp-json/truplexy/v1/chat`). The plugin calls Truplexy with your chat key, which never reaches visitors.

== External service ==

This plugin connects your site to Truplexy (https://truplexy.com), a hosted AI customer-support service. It cannot work without it.

* **What is sent:** each message a visitor types into the chat, and optionally the name and email they enter in the chat form, the background text your own code adds with the `truplexy_chat_context` and `truplexy_chat_customer` filters, and your chat key. Nothing is sent until a visitor sends a message, apart from a request for the chat's title, colours and picture when the widget loads.
* **Where it goes:** from your server to `https://api.truplexy.com`. The visitor's browser only talks to your own site (`/wp-json/truplexy/v1/chat`).
* **The widget script:** `truplexy.min.js` is included in the plugin and served from your site. No third-party CDN is used.
* Terms of service: https://truplexy.com/terms
* Privacy policy: https://truplexy.com/privacy

You need a Truplexy account to get a chat key.

== Installation ==

1. In the Truplexy dashboard, open Integrations → Website chat, add a channel and issue its chat key.
2. In WordPress, open Plugins → Add New and install this plugin (or Upload Plugin with the zip), then activate it.
3. Paste the chat key on the Settings → Truplexy Chat page that opens, then save. It says Connected when the key works. Advanced: define `TRUPLEXY_CHAT_KEY` in `wp-config.php` to keep the key out of the database.
4. In the Truplexy dashboard, open Integrations → Chat widget to set the title, greeting, colour, picture and position. They apply to this site and to every other place the chat is shown.

== Frequently Asked Questions ==

= Where does the widget script come from? =

From the plugin folder (`truplexy.min.js`, the `@truplexy/web` widget). If that file is removed, the plugin falls back to jsDelivr.

= Do I need a separate plugin for WooCommerce? =

No. WooCommerce is a WordPress plugin, so this one already works on every WooCommerce page.

= Can the assistant know who the visitor is? =

Yes. Use the `truplexy_chat_context` filter to return background text, such as the customer's name and plan. It is sent once, privately, when a conversation starts. The filter gets the REST request and the signed-in user's ID (0 for guests):

`add_filter('truplexy_chat_context', function ($context, $request, $user_id) {
    if (!$user_id) return $context;
    $user = get_userdata($user_id);
    return 'Signed in as ' . $user->display_name . ' (' . $user->user_email . ')';
}, 10, 3);`

= How do I link a signed-in customer? =

The default form collects a name (up to 120 characters) and email. The plugin calls PUT /customer and starts the conversation with customer_id; its ticket inherits that identity. Linking failure stops a new identified chat. CUSTOMER_EXISTS is retried once; CUSTOMER_CONFLICT needs correction in the dashboard.

Use truplexy_chat_customer for verified contacts and metadata. The filter runs only for a new conversation and takes precedence over the form; return null to use the form. Its user_id is validated from the WordPress login cookie. Metadata must be a JSON object up to 4 KB.

`add_filter('truplexy_chat_customer', function ($customer, $request, $user_id) {
    if (!$user_id) return null;
    $user = get_userdata($user_id);
    return ['name' => $user->display_name, 'contacts' => [
        ['type' => 'wordpress', 'value' => get_current_blog_id() . ':' . $user_id],
        ['type' => 'email', 'value' => $user->user_email],
    ]];
}, 10, 3);`

TRUPLEXY_CHANNEL_ID in wp-config.php optionally overrides the key's channel. Existing conversations are never relinked. Background context and automatic ticket creation remain best effort. Only REALTIME_NOT_CONFIGURED falls back to polling; channel and authentication failures surface as errors.

When the server supplies identity, skip the form for signed-in users with `add_filter('truplexy_chat_details', function ($details) { return is_user_logged_in() ? 'off' : $details; });`. Guests still see the default details form.

The widget stores its signed session and details in the browser. reset() retains details; use separate storage per account with `add_filter('truplexy_chat_storage_key', function () { return 'truplexy:' . get_current_blog_id() . ':' . get_current_user_id(); });` and reload after signing in or out. This separates browser history; your server still controls authorization. See https://truplexy.com/docs/web-sdk#customers for the identity and server options.

= How is the chat protected from spam? =

Each visitor can make 120 requests a minute, send 20 messages a minute and start 10 chats every 10 minutes. Change these with the `truplexy_chat_request_limit`, `truplexy_chat_rate_limit` and `truplexy_chat_new_chat_limit` filters, for example `add_filter('truplexy_chat_rate_limit', fn () => 40);`, or return 0 to turn one off.

The plugin also tells Truplexy each visitor's IP address. Truplexy then refuses floods, repeated messages and link spam before they use any of your AI replies. Visitors who are refused see how long to wait.

Only pages of your own site can use the chat route. To show the chat on another site of yours, add it with `add_filter('truplexy_chat_allowed_origins', fn () => ['https://shop.example.com']);`.

If your site is behind Cloudflare or another proxy, every visitor may seem to come from the proxy's address. Name the header it sets in wp-config.php, for example `define('TRUPLEXY_TRUSTED_IP_HEADER', 'HTTP_CF_CONNECTING_IP');`, or use the `truplexy_chat_client_ip` filter.

== Changelog ==

= 1.0.7 =
* Spam protection. Every request to the chat route is limited per visitor, not just messages, and so are new chats. Truplexy also gets the visitor's address and refuses floods, repeated messages and link spam before they cost any replies.
* Visitors who are refused see how long to wait, and the send button counts down.
* Only pages of your own site can use the chat route (truplexy_chat_allowed_origins adds others). This also stops another site from starting a chat as a signed-in visitor.
* Behind Cloudflare or another proxy, TRUPLEXY_TRUSTED_IP_HEADER names the header that holds the visitor's address.

= 1.0.6 =
* The first message of a chat is sent sooner: the conversation, its background and its ticket are started in one call to Truplexy instead of three.

= 1.0.5 =
* The chat button is Bubbly, the Truplexy assistant, on your chosen colour. It blinks and glances around, and turns into a close button while the chat is open.
* When you haven't set a header picture or logo, the chat window's header shows Bubbly too.

= 1.0.4 =
* The widget script is always served from your site; the plugin never loads it from a CDN.
* Failed Truplexy calls are written to the PHP error log only when WP_DEBUG_LOG is on.
* Tested with WordPress 7.1.
* New Truplexy look: the chat window's default colour is black, on neutral greys, and the "Powered by" line shows the new Truplexy logo.
* On a dark window, a dark colour such as black stays visible: its buttons and outlines are lifted and its fills get a faint light edge.
* A colour you already chose in the dashboard is kept.

= 1.0.3 =
* A reply from your team now uses the same message card as the assistant's, with the team member's name above it.
* The message box shows a plain coloured border while typing, without the glow.

= 1.0.2 =
* Suggested questions: set up to four in the Truplexy dashboard (Integrations, Chat widget) and visitors can tap one to send it before their first message.
* A cleaner message box: one rounded field with the send button inside it, and a soft ring in your colour while typing.

= 1.0.1 =
* The chat button pops in, lifts when you hover it, presses in when clicked, and spins between its chat and close icons.
* The chat window grows out of the button when it opens and fades back into it when it closes, instead of vanishing. On phones it slides up. Visitors who turn off motion in their system settings see fades only.

= 1.0.0 =
* First release on WordPress.org.
* The widget script is bundled with the plugin instead of loaded from a CDN.
* A conversation whose ticket the team closed is shown read-only for a few days, and the visitor starts a new chat instead of continuing it.
* Settings are removed when the plugin is deleted.
* After activation the plugin opens its settings page, reminds you on the Plugins screen until a key is set, and shows whether the key works.
* Settings screen and rate limiter escape and sanitise their values.

= 0.3.0 =
* How the chat looks (title, greeting, colour, picture, side of the page, theme) is now set once in the Truplexy dashboard under Integrations → Chat widget and shared with every other place the chat is shown. The settings page no longer has those fields; saved values are ignored.

= 0.2.0 =
* Settings: "Keep website chat tickets open" stops the tickets the chat opens from closing on their own after your business's auto-close time.
* Sources can link web pages the assistant searched as well as your articles.

= 0.1.0 =
* First release.

== Upgrade Notice ==

= 1.0.7 =
Spam protection: limits per visitor on every request, with Truplexy refusing floods and repeated messages before they cost any replies.

= 1.0.6 =
The first message of a chat gets its reply sooner.

= 1.0.5 =
The chat button is now Bubbly, the Truplexy assistant, on your chosen colour.

= 1.0.4 =
The new Truplexy look: a black default colour and the new logo. A colour you chose is kept.

= 1.0.3 =
Team replies match the assistant's message card, and the message box focus is a plain border.

= 1.0.2 =
Suggested questions visitors can tap, and a redesigned message box.

= 1.0.1 =
The chat button and window open and close with smooth animations.

= 1.0.0 =
First WordPress.org release. The chat widget is now bundled with the plugin, and the settings page checks that your chat key works.
